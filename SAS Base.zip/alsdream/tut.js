self.focus();

<!-- TRANSLATE -->
<!-- specify titles for each section of TOC #ffcc33 / #A6CAF0 -->
var s1title="<span style='background-color:#A6CAF0'>&nbsp;2&nbsp;</span> Take a Tutorial";
var s2title="<span style='background-color:#A6CAF0'>&nbsp;1&nbsp;</span> Create Sample Data";
var s03title="<span style='background-color:#A6CAF0'>&nbsp;3&nbsp;</span> Set Result Formats";
var s2atitle="SAS Windowing Environment";
var s2btitle="SAS Enterprise Guide";
var s3title="Introduction to SAS Programming";
var s4title="Producing Reports";
var s5title="Creating and Modifying SAS Data Sets";
var s6title="Iterative Processing";
var s7title="Reading Various Types of Raw Data";
var s8title="Check the Newest Updates";
var s9title="License Agreement";

<!-- TRANSLATE -->
<!-- specify titles for each chapter -->
var c01title="Printing the Tutorials (Link to Adobe Reader)";
var c02title="Creating Your Data";
var c03title="SAS Enterprise Guide 3.0 (PDF)";
var c09title="SAS Enterprise Guide 4.1 (PDF)";
var c04title="SAS Windowing Environment (PDF)";
var c05title="Sample Data for All Practices";
var c06title="Filerefs for Selected Practices";
var c07title="Create Sample Data";

var c1title="Basic Concepts";
var c2title="Chapter 2: Referencing Files and Setting Options";
var c3title="Chapter 3: Editing and Debugging SAS Programs";
var c4title="Chapter 4: Creating List Reports";
var c5title="Chapter 5: Creating SAS Data Sets from Raw Data";
var c6title="Chapter 6: Understanding DATA Step Processing";

var c7title="Chapter 7: Creating and Applying User-Defined Formats";
var c8title="Chapter 8: Creating Enhanced List and Summary Reports";
var c9title="Chapter 9: Producing Descriptive Statistics";
var c10title="Chapter 10: Producing HTML Output";

var c11title="Chapter 11: Creating and Managing Variables";
var c12title="Chapter 12: Reading SAS Data Sets";
var c13title="Chapter 13: Combining SAS Data Sets";
var c14title="Chapter 14: Transforming Data with SAS Functions";

var c15title="Chapter 15: Generating Data with DO Loops";
var c16title="Chapter 16: Processing Variables with Arrays";

var c17title="Chapter 17: Reading Raw Data in Fixed Fields";
var c18title="Chapter 18: Reading Free-Format Data";
var c19title="Chapter 19: Reading Date and Time Values";
var c20title="Chapter 20: Creating a Single Observation from Multiple Records";
var c21title="Chapter 21: Creating Multiple Observations from a Single Record";
var c22title="Chapter 22: Reading Hierarchical Files";

<!-- TRANSLATE -->
<!-- specify expanding menus for each chapter -->

//Contents for chapter 2
var menu2=new Array();
menu2[0]=new Array("c2_1.htm","Referencing a SAS Data Library");
menu2[1]=new Array("c2_2.htm","Viewing Contents of a SAS Data Library");
menu2[2]=new Array("c2_3.htm","Viewing Descriptor Information for a Data Set");
menu2[3]=new Array("c2_4.htm","Using SAS System Options to Control Output");
menu2[4]=new Array("c2_5.htm","Resolving Two-Digit Date Values");
menu2[5]=new Array("c2_6.htm","Identifying Settings for System Options");

//Contents for chapter 3
var menu3=new Array();
menu3[0]=new Array("c3_1.htm","Resolving Missing RUN Statement Errors");
menu3[1]=new Array("c3_2.htm","Resolving Missing Semicolon Errors");
menu3[2]=new Array("c3_3.htm","Resolving Common Syntax Errors");
menu3[3]=new Array("c3_4.htm","Resolving Invalid Options Errors");

//Contents for chapter 4
var menu4=new Array();
menu4[0]=new Array("c4_1.htm","Creating a Basic List Report");
menu4[1]=new Array("c4_2.htm","Listing Selected Variables");
menu4[2]=new Array("c4_3.htm","Listing a Subset of Data");
menu4[3]=new Array("c4_4.htm","Sorting an Output Data Set");
menu4[4]=new Array("c4_5.htm","Summing the Values of a Numeric Variable");
menu4[5]=new Array("c4_6.htm","Creating Customized Layouts with Subtotals");
menu4[6]=new Array("c4_7.htm","Adding Titles to a Report");
menu4[7]=new Array("c4_8.htm","Labeling Variables and Double Spacing Output");
menu4[8]=new Array("c4_9.htm","Formatting Variable Values");

//Contents for chapter 5
var menu5=new Array();
menu5[0]=new Array("c5_1.htm","Reading a Raw Data File");
menu5[1]=new Array("c5_2.htm","Creating a New Variable");
menu5[2]=new Array("c5_3.htm","Reading Data Lines as Instream Data");
menu5[3]=new Array("c5_4.htm","Writing Values to a Raw Data File");

//Contents for chapter 6
var menu6=new Array();
menu6[0]=new Array("c6_1.htm","Creating a New Variable");
menu6[1]=new Array("c6_2.htm","Testing a Program without Creating a Data Set");
menu6[2]=new Array("c6_3.htm","Using the PUT Statement to Test for Values");

//Contents for chapter 7
var menu7=new Array();
menu7[0]=new Array("c7_1.htm","Creating a User-Defined Format");
menu7[1]=new Array("c7_2.htm","Formatting a Variable Using a User-Defined Format");
menu7[2]=new Array("c7_3.htm","Listing User-Defined Formats");

//Contents for chapter 8
var menu8=new Array();
menu8[0]=new Array("c8_1.htm","Using the Nonwindowing Mode");
menu8[1]=new Array("c8_2.htm","Displaying Selected Variables");
menu8[2]=new Array("c8_3.htm","Selecting Observations for a Report");
menu8[3]=new Array("c8_4.htm","Assigning a Format to a Column");
menu8[4]=new Array("c8_5.htm","Assigning a Width to a Column");
menu8[5]=new Array("c8_6.htm","Specifying Column Heading Options");
menu8[6]=new Array("c8_7.htm","Ordering Rows in a Report");
menu8[7]=new Array("c8_8.htm","Creating a Summary Report");
menu8[8]=new Array("c8_9.htm","Specifying Statistics in a Summary Report");
menu8[9]=new Array("c8_10.htm","Specifying an Across Variable in a Summary Report");
menu8[10]=new Array("c8_11.htm","Specifying a Computed Variable in a Report");

//Contents for chapter 9
var menu9=new Array();
menu9[0]=new Array("c9_1.htm","Producing a Set of Descriptive Statistics");
menu9[1]=new Array("c9_2.htm","Producing a Series of Descriptive Statistics");
menu9[2]=new Array("c9_3.htm","Producing a Grouped Series of Statistics");
menu9[3]=new Array("c9_4.htm","Producing an Output Data Set");
menu9[4]=new Array("c9_5.htm","Producing a Set of Frequency Tables");
menu9[5]=new Array("c9_6.htm","Producing a Two-Way Crosstabulation");
menu9[6]=new Array("c9_7.htm","Producing Three-Way Crosstabulations");
menu9[7]=new Array("c9_8.htm","Controlling the Content of Crosstabulation Output");

//Contents for chapter 10
var menu10=new Array();
menu10[0]=new Array("c10_1.htm","Creating HTML Output Using a SAS Data Set");
menu10[1]=new Array("c10_2.htm","Creating HTML Output Using Two SAS Data Sets");
menu10[2]=new Array("c10_3.htm","Linking a Table of Contents Using Two SAS Data Sets");
menu10[3]=new Array("c10_4.htm","Specifying Link Paths in ODS HTML Output");
menu10[4]=new Array("c10_5.htm","Specifying a Destination for HTML Files");
menu10[5]=new Array("c10_6.htm","Applying a New Style to HTML Output");

//Contents for chapter 11
var menu11=new Array();
menu11[0]=new Array("c11_1.htm","Creating a Running Total");
menu11[1]=new Array("c11_2.htm","Keeping and Dropping Variables");
menu11[2]=new Array("c11_3.htm","Formatting and Labeling Variables");
menu11[3]=new Array("c11_4.htm","Using a SELECT Group to Assign Values Conditionally");

//Contents for chapter 12
var menu12=new Array();
menu12[0]=new Array("c12_1.htm","Creating a Data Set from an Existing Data Set");
menu12[1]=new Array("c12_2.htm","Selecting Observations Based on a Condition");
menu12[2]=new Array("c12_3.htm","Keeping and Dropping Variables");
menu12[3]=new Array("c12_4.htm","Grouping Variables");
menu12[4]=new Array("c12_5.htm","Detecting the End of a Data Set");

//Contents for chapter 13
var menu13=new Array();
menu13[0]=new Array("c13_1.htm","Combining Observations One-to-One");
menu13[1]=new Array("c13_2.htm","Subsetting Data While Concatenating");
menu13[2]=new Array("c13_3.htm","Interleaving Data Sets");
menu13[3]=new Array("c13_4.htm","Merging Data Sets");
menu13[4]=new Array("c13_5.htm","Merging Sorted Data Sets");
menu13[5]=new Array("c13_6.htm","Excluding Unmatched Observations");
menu13[6]=new Array("c13_7.htm","Merging Sorted Data Sets and Selecting Variables");

//Contents for chapter 14
var menu14=new Array();
menu14[0]=new Array("c14_1.htm","Converting Character Data to Numeric Data");
menu14[1]=new Array("c14_2.htm","Converting Numeric Data to Character Data");
menu14[2]=new Array("c14_3.htm","Extracting the Month from a Date Value");
menu14[3]=new Array("c14_4.htm","Extracting the Year Value from a Date Value");
menu14[4]=new Array("c14_5.htm","Extracting the Year and Month from a Date Value");
menu14[5]=new Array("c14_6.htm","Creating a SAS Date Value");
menu14[6]=new Array("c14_7.htm","Counting SAS Date Intervals");
menu14[7]=new Array("c14_8.htm","Extracting a Word from a Character Value");
menu14[8]=new Array("c14_9.htm","Extracting a Substring from a Character Value");
menu14[9]=new Array("c14_10.htm","Replacing the Contents of a Character Variable");
menu14[10]=new Array("c14_11.htm","Searching the Values of a Character Variable");

//Contents for chapter 15
var menu15=new Array();
menu15[0]=new Array("c15_1.htm","Constructing a Simple DO Loop");
menu15[1]=new Array("c15_2.htm","Constructing a Nested DO Loop");
menu15[2]=new Array("c15_3.htm","Iteratively Processing Data from a SAS Data Set");
menu15[3]=new Array("c15_4.htm","Executing a DO Loop until a Condition Is True");
menu15[4]=new Array("c15_5.htm","Executing a DO Loop while a Condition Is True");
menu15[5]=new Array("c15_6.htm","Constructing a DO Loop to Execute until a Condition Is True");

//Contents for chapter 16
var menu16=new Array();
menu16[0]=new Array("c16_1.htm","Grouping and Processing Variables as an Array");
menu16[1]=new Array("c16_2.htm","Defining and Processing a Two-Dimensional Array");

//Contents for chapter 17
var menu17=new Array();
menu17[0]=new Array("c17_1.htm","Using Column Input to Read Data from a Raw Data File");
menu17[1]=new Array("c17_2.htm","Using Pointer Controls in an INPUT Statement");
menu17[2]=new Array("c17_3.htm","Using + Column Pointer Controls");
menu17[3]=new Array("c17_4.htm","Using Formatted Input to Read Data in a Raw Data File");

//Contents for chapter 18
var menu18=new Array();
menu18[0]=new Array("c18_1.htm","Using Simple List Input to Read a Raw Data File");
menu18[1]=new Array("c18_2.htm","Reading Data Separated by Nonblank Delimiters");
menu18[2]=new Array("c18_3.htm","Reading Data That Contains Missing Values");
menu18[3]=new Array("c18_4.htm","Defining the Length for a Variable");
menu18[4]=new Array("c18_5.htm","Reading Standard and Nonstandard Values");
menu18[5]=new Array("c18_6.htm","Creating a Comma-Delimited Raw Data File");
menu18[6]=new Array("c18_7.htm","Mixing Input Styles");

//Contents for chapter 19
var menu19=new Array();
menu19[0]=new Array("c19_1.htm","Using Dates and Times in Calculations");
menu19[1]=new Array("c19_2.htm","Displaying Date Values using a SAS Date Format");

//Contents for chapter 20
var menu20=new Array();
menu20[0]=new Array("c20_1.htm","Reading Multiple Records in Order");
menu20[1]=new Array("c20_2.htm","Reading Multiple Records Non-Sequentially");
menu20[2]=new Array("c20_3.htm","Reading Multiple Records In and Out of Order");

//Contents for chapter 21
var menu21=new Array();
menu21[0]=new Array("c21_1.htm","Reading Repeating Blocks of Data in a Single Record");
menu21[1]=new Array("c21_2.htm","Creating One Observation for Each Repeating Field");
menu21[2]=new Array("c21_3.htm","Reading a Varying Number of Repeating Fields");

//Contents for chapter 22
var menu22=new Array();
menu22[0]=new Array("c22_1.htm","Creating One Observation per Detail Record");
menu22[1]=new Array("c22_2.htm","Creating One Observation per Header Record");


<!-- developers: don't edit below this line ----------------------------------- -->
<!-- -------------------------------------------------------------------------- -->
<!-- -------------------------------------------------------------------------- -->
<!-- -------------------------------------------------------------------------- -->

var thisWindow = window.location.href;
var myName = thisWindow.substring(thisWindow.lastIndexOf("/")+1,thisWindow.lastIndexOf("."));
var myModule = myName.substring(myName.lastIndexOf("c"),myName.lastIndexOf("_"));
var chapterTitle= myModule+"title";
var myModuleNumber = myModule.substring(1);
var myPage = myName.substring(myName.lastIndexOf("_")+1, myName.length);
var lastChar = myName.charAt(myName.length-1);
var alreadyopen = true;
if (lastChar >= 'a') var setTitle = 0;
else {
   var setTitle = 1;
   self.name="SAS";
}

function setChapterTitle() {
   document.write(eval(chapterTitle));
}

if(document.images){
homen=new Image();homen.src="navimages/home.gif";
homey=new Image();homey.src="navimages/home_h.gif";
tocn=new Image();tocn.src="navimages/toc.gif";
tocy=new Image();tocy.src="navimages/toc_h.gif";
bybn=new Image();bybn.src="navimages/byb.gif";
byby=new Image();byby.src="navimages/byb_h.gif";
}

<!-- code for expandable table of contents -->

if (!document.getElementById)
    document.getElementById = function() { return null; }

function initializeMenu(menuID, chapterID) {
    var chapterlinks = document.getElementById(menuID);
    var chapter = document.getElementById(chapterID);
    if (chapterlinks == null || chapter == null) return;
    chapter.onclick = function() {
        var display = chapterlinks.style.display; 
        this.parentNode.style.backgroundImage =
            (display == "block") ? "url(navimages/cntplus.gif)" : "url(navimages/cntminus.gif)";
        chapterlinks.style.display = (display == "block") ? "none" : "block";
        return false;
    }
}

<!--  end of code for expandable table of contents -->

<!-- create TOC entries in conttab.htm -->
function writeTOC(toclsn) {
   lsn=toclsn.substring(1);
   menunum="menu"+lsn;
   anum=eval(menunum).length;
   for (var i=0; i<anum; i++)
document.write('<LI><A href="'+eval('menu'+lsn+'[i][0]')+'" target="SAS">' +eval('menu'+lsn+'[i][1]')+'</A></LI>');
}

 function rOver(boxL){
   if(document.images)
      {document[boxL].src=eval(boxL+'y.src');}
}

function rOut(boxL){
   if(document.images)
      {document[boxL].src=eval(boxL+'n.src');}
}

var newWindow=null;
function openContentsIndex() {
   if(newWindow && newWindow.open && !newWindow.closed) newWindow.focus();
   else {
//    newWindow = window.showModalDialog('conttab.htm','modal','top=0,left=0,width=550,height=500,resizable=1,scrollbars=yes');
      newWindow = window.open('','ContentsIndex','top=0,left=0,width=550,height=500,resizable=1,scrollbars=yes');
      newWindow.focus(); 
	  var newURL=newWindow.document.URL;
      if (newURL=="about:blank") {
	     newWindow.location.href="conttab.htm";  
	  }
   }
}

function openOther(page) {
   newWindow = window.open('','Other','top=0,left=0,width=600,height=750,resizable=1,scrollbars=yes');
      if (alreadyopen) {
         alreadyopen = false;
      }
   alreadyopen = true;
   newWindow.location.href=page;
}

function openOther2(page) {
   newWindow = window.open('','Other2','top=25,left=25,width=600,height=750,resizable=1,scrollbars=yes');
      if (alreadyopen) {
         alreadyopen = false;
      }
   alreadyopen = true;
   newWindow.location.href=page;
}

function resizePage() {
  if(navigator.appVersion.indexOf("Win")!=-1) {
   if(window.resizeTo) {
      if(window.innerHeight) {
         currentWidth=window.innerWidth;
      }
      else if (document.body.clientHeight) {
         currentWidth=document.body.clientWidth;
      }
      else currentWidth=550;
      self.resizeBy((mywidth-currentWidth),0);
   }
  }
}

function sizePractice() {
  if(navigator.appVersion.indexOf("Win")!=-1) {
   if (window.resizeTo) {
      if (window.innerHeight) {
         mywidth = window.innerWidth;
      }
      else if (document.body.clientHeight) {
         mywidth = document.body.clientWidth;
      }
      else mywidth=465;
      if (mywidth>465) self.resizeBy(-(mywidth-465),0);
    }
   }
}

function removeFrames() {
   if (window != top) top.location.href = location.href;
}

removeFrames();